const express = require('express');
const router = express.Router();

const { check } = require('express-validator');
const auth = require('../../middleware/auth');

const { register } = require('../../controller/auth');
const { updateProfile, changePassword } = require('../../controller/user');
// @route    POST api/users
// @desc     Register user
// @access   Public
router.get('/', async (req, res) => {
  res.json('23234234234234');
  console.log('111');
});
router.post(
  '/',
  check('name', 'Name is required').notEmpty(),
  check('email', 'Please include a valid email').isEmail(),
  check(
    'password',
    'Please enter a password with 6 or more characters'
  ).isLength({ min: 6 }),
  register
);

router.put(
  '/:id',
  auth,
  check('name', 'Name is required').notEmpty(),
  updateProfile
);

router.put(
  '/:id/password',
  auth,
  check(
    'newPassword',
    'Please enter a newpassword with 6 or more characters'
  ).isLength({ min: 6 }),
  changePassword
);
module.exports = router; /* end */ 